import React from 'react';
export const Footer = ()=>{
    return (
        <p>CopyRight Brain Mentors 2021</p>
    )
}