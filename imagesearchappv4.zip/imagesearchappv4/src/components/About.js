import React from 'react';
export const About = ()=>{
    return (<h1>I am About </h1>);
}