import { useEffect, useState } from "react"

import React from 'react'
// Pure C
const A = React.memo(()=>{
    const [a, setA] = useState(0);
    // useEffect(()=>{
    //     console.log("Did Mount, Update");
    // },[a,b]);
    // Life Cycle
    useEffect(()=>{
             console.log("Did Mount, Update");
         });
});