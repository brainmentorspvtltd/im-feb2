import React, { useState } from 'react';
import { LikeContext } from '../utils/context';
import {connect} from 'react-redux';
 const TotalLikes = (props)=>{
    // const [total,setTotal] = useState(0);
    // const giveMeData = (dt)=>{
    //     console.log('Data is ',dt);
    //     //total = dt
    //     setTotal(total+1);

    // }

    return (
        <p>Total Likes {props.totallikes}</p>
    );

   // return (
        // <LikeContext.Consumer>{
        //     (value)=>{
        //         console.log('Total Consumer ', value.totalLike);
        //         return (
        //             <>
        //             <p>Total Likes {value.totalLike}</p>
        //             <button onClick={()=>{
        //                 giveMeData(value.totalLike)
        //             }}>Get Total </button>
        //             </>
        //         )
        //     }
        //     }

        // </LikeContext.Consumer>
   // );
}

const mapStateToProps = (state)=>{
    return {totallikes:state.like};
}

export default connect(mapStateToProps)(TotalLikes);

