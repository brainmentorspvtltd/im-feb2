import React from 'react';
import {NavLink} from 'react-router-dom';
import './Header.css';
export const Header = ()=>{
    console.log('Header ',window.location.pathname);

    return (
        <>
        <h1>Welcome to Our Application</h1>
      <NavLink exact activeClassName="alert-danger" to="/" >Home</NavLink> &nbsp;&nbsp;
      <NavLink  activeClassName="alert-danger" to="/about" >About Us</NavLink>
      &nbsp;&nbsp;
      <NavLink  activeClassName="alert-danger" to="/search" >Search App</NavLink>
        </>
    )
}