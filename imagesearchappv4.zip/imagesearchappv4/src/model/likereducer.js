export const likeReducer = (state = {like:0}, action)=>{
    console.log('Reducer ',action);
    if(action.type=='likeplus'){
        return {...state, like:action.payload.like + state.like};
    }
    return state;
}