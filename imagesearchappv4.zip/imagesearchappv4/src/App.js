import React from 'react';
import { SearchPage } from './containers/SearchPage';
import { LikeContext } from './utils/context';
import {NavLink, Route, Switch} from 'react-router-dom';
import { Home } from './components/Home';
import { About } from './components/About';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
const App = ()=>{
  let totalLike = 0;

  const getTotalLike=()=>{
    totalLike++;
    obj.totalLike = totalLike;
    console.log('Total Like is ',obj.totalLike);

    //return totalLike;
  }
  const obj = {totalLike, getTotalLike};

{/* <LikeContext.Provider value={obj}>
        <SearchPage/>
      </LikeContext.Provider> */}

  return (
    <div className='container'>
      <Header/>


      <Switch>
        <Route path="/" exact component={Home} />
        <Route path="/about" exact component={About} />
        <Route path="/search" exact component={SearchPage} />
        <Route render={()=>{
          return (<h1>404 File Not Found....</h1>)
        }}/>

      </Switch>
     <Footer/>
      </div>


    // <SearchPage/>


  );
}
export default App;