export const actionCreator= (payload, type)=>{
    const action =  {
        payload:payload,
        type:type
    }
    return action;
}