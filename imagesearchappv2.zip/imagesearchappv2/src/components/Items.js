import React from 'react';
import { Item } from './Item';
export const Items = (props)=>{
    return (<div>
        {props.listofimages.map((current,index)=><Item key={index} url={current.images.original.url}/>)}
        {/* {props.listofimages[0].images.original.url} */}

    </div>)
}