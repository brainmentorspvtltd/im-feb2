import React, { useState } from 'react';
import { LikeContext } from '../utils/context';
export const TotalLikes = (props)=>{
    const [total,setTotal] = useState(0);
    const giveMeData = (dt)=>{
        console.log('Data is ',dt);
        //total = dt
        setTotal(total+1);

    }

    return (
        <LikeContext.Consumer>{
            (value)=>{
                console.log('Total Consumer ', value.totalLike);
                return (
                    <>
                    <p>Total Likes {value.totalLike}</p>
                    <button onClick={()=>{
                        giveMeData(value.totalLike)
                    }}>Get Total </button>
                    </>
                )
            }
            }

        </LikeContext.Consumer>
    );
}