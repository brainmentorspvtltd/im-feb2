import React from 'react';
import { SearchPage } from './containers/SearchPage';
import { LikeContext } from './utils/context';
const App = ()=>{
  let totalLike = 0;

  const getTotalLike=()=>{
    totalLike++;
    obj.totalLike = totalLike;
    console.log('Total Like is ',obj.totalLike);

    //return totalLike;
  }
  const obj = {totalLike, getTotalLike};



  return (


      <LikeContext.Provider value={obj}>
        <SearchPage/>
      </LikeContext.Provider>


  )
}
export default App;