import React from 'react';
import { Items } from '../components/Items';
import { SearchInput } from '../components/SearchInput';
import { TotalLikes } from '../components/TotalLikes';
import { doAjax } from '../utils/ajax';
export class SearchPage extends React.Component{
constructor(props){
    super(props);
    this.searchValue = '';
    console.log('I am ',this);
    this.state = {images:[]};

}
componentDidMount(){
    this.getAjaxData();
}

getAjaxData(searchValue){
    const promise = doAjax(searchValue);
    promise.then(result=>{
        console.log('Result is ::::: ',result);
        this.setState({images:result.data.data});
    }).catch(err=>{
        console.log('Error is ',err);
    })

    // promise.then(response=>{
    //         response.json().then(result=>{
    //             console.log(result.data);
    //             this.setState({images:result.data});
    //         }).catch(err=>{
    //             console.log('Error in Server JSON ');
    //         });
    // }).catch(err=>{
    //     console.log("Unable to get response from the server");
    // });
}

takeSearchInput(val){
    this.searchValue = val;

    this.getAjaxData(this.searchValue);
}




render(){
    console.log('Search Page Render Call');
    return (
        <div className='container'>
            <h1 className='alert-info text-center'>Search Image App</h1>
            <TotalLikes />
            <SearchInput takeinput={(str)=>{
                this.takeSearchInput(str);
            }}/>
            <Items listofimages={this.state.images}/>
        </div>
    )
}
}