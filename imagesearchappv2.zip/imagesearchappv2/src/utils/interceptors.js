import axios from 'axios';
export function loadInterceptor(){
    console.log("Interceptor Loaded...");
axios.interceptors.request.use(function (request) {
    // Do something before request is sent
    //request.tokenId = localStorage.tokenId;

    request.tokenId = "A123456";
    console.log('Interceptor Running....', request.tokenId);
    return request;
  }, function (error) {
    // Do something with request error
    return Promise.reject(error);
  });
}