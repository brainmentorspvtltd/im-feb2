import React from 'react';
 const Operation = (props)=>{
    console.log('Operation Render');
    return (


            <button onClick={props.oprname}>{props.label}</button>


    );
}
export default Operation;