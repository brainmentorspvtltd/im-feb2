import React from 'react';
 const Output = (props)=>{
    console.log('Output Render');
    return (
        <h3> {props.fullname}</h3>
    );
}
export default Output;