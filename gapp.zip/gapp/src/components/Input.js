import React from 'react';
 const Input = (props)=>{
    console.log('Input Render');
     let placeHolder = `Type ${props.label} Here`;
    return (
        <div className='form-group'>
        <label>{props.label}</label>
        <input onChange={props.takeinput} className='form-control' type='text' placeholder={placeHolder}/>
        </div>
    );
}

export default Input;