import React from 'react';
export const Title = ()=>{
    console.log('Title Render');
    return (<h1 className='alert-info'>Greet App</h1>);
}
//export default Title;

