import { Component } from "react";
import Input from "../components/Input";
import Operation from "../components/Operation";
import Output from "../components/Output";
import { Title } from "../components/Title";

class Greet extends Component{

    constructor(){
        super();
        console.log('1. Constructor Call', this);
        this.firstName = '';
        this.lastName = '';
        this.fullName = '';
        console.log('This is ',this);
        this.bindEvents();
        this.state = {msg:''};
        // this.state = {msg:'',a:0,b:0,w:{p:88,e:[{},{},{}]}}

    }

    bindEvents(){
        this.firstNameInput = this.takeFirstName.bind(this);
        //this.lastNameInput = this.takeLastName.bind(this);
    }

    takeFirstName(event){
        console.log('this is ',this);
        this.firstName = event.target.value;
        console.log('Take First Name Called..', this.firstName);
    }

    takeLastName(event){
        this.lastName = event.target.value;
        console.log('Take Last Name Called...',this.lastName);
    }

    sayWelcome(){
         this.fullName = this.firstName +" " +this.lastName;
        console.log('Full Name is ',this.fullName);
        //this.state.msg = 'ghdkjgdfkg'; Mutable
        //this.setState({...this.state, msg:'Welcome '+this.fullName}); // Immutable Style
        this.setState({msg:'Welcome '+this.fullName},()=>{
            console.log('State Done...');
        }); // Immutable Style
        console.log('I Will Call First.......');
    }
    clearAll(){
        console.log('Clear All Called..');
    }

    //Comment
    /*
    Multi Line Comment
    */
    render(){
        console.log('2. Render Called...');
        return (
            <>
            <Title/>
            <Input label='First Name' takeinput={this.firstNameInput} />
            <Input label='LastName' takeinput ={(event)=>{
                this.takeLastName(event);
            }} />
            <br/>
            <Operation label="Greet" oprname={this.sayWelcome.bind(this)} />
            <Operation label="Clear All" oprname={this.clearAll} />
            <Output fullname = {this.state.msg}/>
            </>

        );
    }
}
export default Greet;