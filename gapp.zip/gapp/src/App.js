import React from 'react';
import Greet from './containers/Greet';


function App(){
  return (
    <Greet/>
  )
}
export default App;