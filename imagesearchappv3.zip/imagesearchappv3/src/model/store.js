import {createStore} from 'redux';
import {likeReducer} from './likereducer';
export const store = createStore(likeReducer);
store.subscribe(()=>{
    console.log('Store Update....', store);
})
