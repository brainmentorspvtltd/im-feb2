import React from 'react';
export const LikeContext =
React.createContext({totalLike:0,getTotalLike:function(){}});