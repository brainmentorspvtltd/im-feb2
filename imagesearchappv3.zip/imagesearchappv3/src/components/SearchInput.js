import React, { useRef } from 'react';

export const SearchInput=(props) =>{
    const searchBox = useRef('');
    const takeSearchValue= ()=>{
        let searchValue = searchBox.current.value;
        console.log(searchValue);
        props.takeinput(searchValue);
    }
    return (
        <div className ='form-group'>
        <label>Search Image</label>
        <input ref={searchBox}   type='text' placeholder='Type to Search Image' className='form-control'/>
        <button onClick={takeSearchValue} className='btn btn-primary'>Search Now</button>
        </div>
    )
}
