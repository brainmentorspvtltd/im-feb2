import React, { useState } from 'react';
import { LikeContext } from '../utils/context';
import {store} from '../model/store';
import { actionCreator } from '../actions/actioncreator';
export const Like = (props)=>{
    console.log('Like Render....');
    // useState({x:0,y:0,z:0,{}})
    const [like,setLike] = useState(0); // this.state.like = 0;
    const myStyle = {
        width:'100px',
        height:'100px',
        cursor:'pointer'

    }
    const plusIt = ()=>{
        setLike(like+1); // this.setState({like:val})
        console.log('Value of Like is ',);
        const action = actionCreator({like: 1},"likeplus");
        store.dispatch(action);
    }
    return (
        <>

                    <img onClick={()=>{
                        plusIt();

                    }} style={myStyle} src="https://i.pinimg.com/originals/39/44/6c/39446caa52f53369b92bc97253d2b2f1.png"/>
                    {like}

        {/* <LikeContext.Consumer>{
            value=>{
                return (
                    <span>
                    <img onClick={()=>{
                        plusIt();
                        value.getTotalLike();
                    }} style={myStyle} src="https://i.pinimg.com/originals/39/44/6c/39446caa52f53369b92bc97253d2b2f1.png"/>
                    {like}
                    </span>
                    )
            }
            }

        </LikeContext.Consumer> */}

        </>


    );
}