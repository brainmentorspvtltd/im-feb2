import React from 'react';
import { Like } from './Like';
export const Item = (props)=>{
    const myStyle = {
        width:'200px',
        height:'200px'

    }
    return (<div>
            <img style={myStyle} src={props.url}/>
            <Like/>

    </div>);
}