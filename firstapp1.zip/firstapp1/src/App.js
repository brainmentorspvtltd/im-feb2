import React from 'react';
import './App.css';
import { Header } from './components/Header';
import {Footer} from './components/Footer';
import { SideBar } from './components/SideBar';
 function App(){
   let year = 2021;
  //return React.createElement("h1",null,'Hello ReactJS');
  //return React.createElement("h1",null,'Hello ReactJS') React.createElement("h2",null,'Hi ReactJS');
  //return (<h1>Hello ReactJS</h1><h2>Hi React JS</h2>);
  const myStyle= {
    backgroundColor:'green'
  }
  let names = ["Amit","Ram","Shyam"];
  return (<div>
    <Header/>
    <SideBar/>
    <ul>
    {/* <li>Amit</li>
    <li>Ram</li>
    <li>Shyam</li> */}
    {names.map(name=><li>{name}</li>)}
    </ul>
    {year>2020?<p>Current Year {year}</p>:<p>Previous Year</p>}
    <h1 className='red'>Hello React JS - {year}</h1>
    <h2 style={myStyle}>Hi React JS</h2>
    <Footer/>
  </div>)
}
export default App;