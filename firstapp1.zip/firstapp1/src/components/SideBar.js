import React from 'react';
export const SideBar = ()=>{
    return (
        <h1>I am a SideBar</h1>
    );
}