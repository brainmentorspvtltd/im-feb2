import ReactDOM from 'react-dom';
import App from './App';
import React from 'react';
// ReactDOM.render(React.createElement(App),
// document.querySelector('#root'));
ReactDOM.render(<App/>,document.querySelector('#root'));