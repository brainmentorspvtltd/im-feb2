const expenseOperations = {
    expenses:[],
    getExpenses(){
        return this.expenses;
    },
    getTotal(){
        return this.expenses.length;
    },
    findById(id){
        return this.expenses.find(expense=>expense.id==id);
    },

    toggleMark(id){
        let expenseObject = this.findById(id);
        expenseObject.toggleIt();
    },
    countMarked(){
        return this.expenses.filter(expense=>expense.isMarked).length;
    },
    countUnMarked(){
        return this.getTotal() - this.countMarked();
    },

    add(id, name, cost, date, remarks){
        // create an object
        let expenseObject = new Expense(id, name, cost, date, remarks);
        // add in array
        this.expenses.push(expenseObject);
        return expenseObject;
    },

    getTotalCost(){
        return this.expenses.reduce((acc,expense)=>acc+parseInt(expense.cost),acc=0);
    },



    remove(){
        this.expenses = this.expenses.filter(expense=>!expense.isMarked);
        return this.expenses;
    },
    search(){

    },
    update(){

    },
    sort(){

    }
}