class Expense{
    constructor(id, name, cost, date, remarks){
        this.id = id;
        this.name = name;
        this.cost = cost;
        this.date = date;
        this.remarks = remarks ;
        this.isMarked = false;
    }
    toggleIt(){
        this.isMarked = !this.isMarked;
    }
}



// function Expense(id, name, cost, date, remarks){
// this.id = id;
// this.name = name;
// this.cost = cost;
// this.date = date;
// this.remarks = remarks;
// this.isMarked = false;
// }
// Expense.prototype.toggleIt= function(){
//     this.isMarked = !this.isMarked;
// }

