window.addEventListener('load',init);
// Event Binding
function bindEvents(){
    document.querySelector('#add').addEventListener('click',addExpense);
    document.querySelector('#delete').addEventListener('click',deleteMarked);
    document.querySelector('#save').addEventListener('click',save);
    document.querySelector('#load').addEventListener('click',load);
}

function save(){
    if(window.localStorage){
        let expenses = expenseOperations.getExpenses();
        let json = JSON.stringify(expenses);
        console.log(json);
        localStorage.expenses = json;
        alert("Data Saved...");
    }
    else{
        alert("Browser is outdated no support of LocalStorage...");
    }
}

function load(){
    if(window.localStorage){
        if(localStorage.expenses){
            let expArr = JSON.parse(localStorage.expenses);
            expArr.forEach(exp=>expenseOperations.add(exp.id, exp.name, exp.cost, exp.date, exp.remarks));
            printExpenses(expenseOperations.getExpenses());
            updateCounts();
        }
        else{
            alert("No Data to Load....");
        }
    }
    else{
        alert("Browser is outdated no support of LocalStorage...");
    }
}

function deleteMarked(){
    let expenses = expenseOperations.remove();
    printExpenses(expenses);
    updateCounts();

}

function init(){
    updateCounts();
    bindEvents();
}

function addExpense(){
    let id = document.querySelector('#id').value;
    let name = document.querySelector('#name').value;
    let cost = document.querySelector('#cost').value;
    let date = document.querySelector('#date').value;
    let remarks = document.querySelector('#remarks').value;
    let expenseObject = expenseOperations.add(id, name, cost, date, remarks);
    console.log(id, name, cost, date, remarks);
    printExpense(expenseObject);
    updateCounts();
}
function updateCounts(){
    document.querySelector('#totalmarked').innerText = expenseOperations.countMarked();
    document.querySelector('#totalunmarked').innerText = expenseOperations.countUnMarked();
    document.querySelector('#total').innerText = expenseOperations.getTotal();
    document.querySelector('#totalcost').innerText = 'Total Cost is '+
    expenseOperations.getTotalCost();
}
function toggleMark(){
    let id = this.getAttribute('expid');
    console.log('This is ',id);
    expenseOperations.toggleMark(id);
    updateCounts();
    let tr = this.parentNode.parentNode;
    tr.classList.toggle('alert-danger');
    //tr.className = 'alert-danger';
}
function edit(){

}
function createIcon(className, fn, id){
    let iTag = document.createElement('i');

    iTag.addEventListener('click',fn);
    iTag.className = className;
    iTag.setAttribute('expid',id);
    //'fas fa-trash';
    //<i class="fas fa-edit" onclick=""></i>
    return iTag;
}
function printExpenses(expenses){
    document.querySelector('#expenses').innerHTML = '';
    expenses.forEach(printExpense);
}
function printExpense(expenseObject){
    let tbody = document.querySelector('#expenses');
    let tr = tbody.insertRow();
    for(let key in expenseObject){
        if(key=='isMarked' || key=='toggleIt'){
            continue;
        }
        let td = tr.insertCell();
        td.innerText= expenseObject[key];
    }
    let td = tr.insertCell();
    td.appendChild(createIcon('fa fa-trash me-2 hand', toggleMark, expenseObject.id));
    td.appendChild(createIcon('fa fa-edit hand',edit, expenseObject.id));


}