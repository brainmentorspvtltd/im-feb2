function doAjax(){
    var httpRequest = new window.XMLHttpRequest();
    httpRequest.onreadystatechange=function(){
        console.log(httpRequest.readyState);
        if(httpRequest.readyState==4 && httpRequest.status==200){
        console.log(httpRequest.responseText);
        }
        }
        httpRequest.open('GET','https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/singers.json',true);
        httpRequest.send(null);
    }

   async  function doAjax2(){
       // const url = 'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/singers.json';
      const url = 'http://127.0.0.1:5500/server/data.json';
      console.log('Before Call');
      try{
      const response = await fetch(url);
      let json = await response.json();
      console.log(json);
      console.log('Blocked....');
      }
      catch(ex){
          console.log('Error' , ex);
      }
    //    const promise = fetch(url);
    //    promise.then(response=>{
    //         response.json().then (data=>console.log(data)).catch(err=>console.log('INvalid JSON',err))
    //    }).catch(err=>console.log('Server Call Fails',err));
      return 100;
}