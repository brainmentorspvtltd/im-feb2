 module.exports  =  {
     isStaticFile(fileName){
        const extensions = [".html",".css",".png",".ico",".jpeg",".js"];
        const path = require('path');
        const ext = path.extname(fileName);
        return extensions.indexOf(ext)>=0;

    },
     readAndServeStaticFile(url, response){
        const fs = require('fs');
            const path = require('path');
            const fullPath= path.join(__dirname,'/public'+url);
            console.log("Full Path is ",fullPath);
            const readStream = fs.createReadStream(fullPath);
            readStream.pipe(response);
    }
 }




