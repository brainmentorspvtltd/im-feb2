const http = require('http');
const isStaticThings = require('./staticfileserve');
// CallBack
// function handleRequestAndResponse(request, response){

// }
// const server = http.createServer(handleRequestAndResponse); // Attach Fn as CallBack
// when request comes then this callback works, N Times call (N Times request)
const server = http.createServer((request, response)=>{
    console.log(request.url, __dirname);
    let url = request.url;
    if(request.url=='/'){
        url = '/index.html';
    }
    if(isStaticThings.isStaticFile(url)){
        isStaticThings.readAndServeStaticFile(url, response);
    }
    else{

    }
    // __dirname - global constant
    // give the current directory path
//     if(request.url =='/index.html'){

//         console.log('Response Ends....');
//     }
//     else{
// response.write('Hello User....');
// response.end();
//     }

});

// Start then this callback will work
server.listen(process.env.PORT || 5000,()=>{
    console.log('Server Started....',server.address().port);
})