import React, { useState } from 'react';
export const Like = (props)=>{
    console.log('Like Render....');
    const [like,setLike] = useState(0); // this.state.like = 0;
    const myStyle = {
        width:'100px',
        height:'100px',
        cursor:'pointer'

    }
    const plusIt = ()=>{
        setLike(like+1); // this.setState({like:val})
    }
    return (<>
            <img onClick={plusIt} style={myStyle} src='https://i.pinimg.com/originals/39/44/6c/39446caa52f53369b92bc97253d2b2f1.png'/>
            {like}
    </>);
}