import React from 'react';
import { SearchPage } from './containers/SearchPage';
const App = ()=>{
  return (
    <div>
      <SearchPage/>
    </div>
  )
}
export default App;