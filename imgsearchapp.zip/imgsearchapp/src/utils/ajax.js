import axios from 'axios';
export function doAjax(searchValue="tom and jerry"){
     const URL = `https://api.giphy.com/v1/gifs/search?api_key=vFRSFWo6g7vJ7ZAjt3DMDolU52ORTxwH&q=${searchValue}&limit=5`;
    // const promise = fetch(URL);
    // return promise;
    const promise = axios.get(URL);
    return promise;
}